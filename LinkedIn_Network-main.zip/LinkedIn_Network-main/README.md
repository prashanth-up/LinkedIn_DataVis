# LinkedIn_Network
Streamlit app for creating network and bar graphs based on LinkedIn connection data. Created and deployed Dec 2021 by Jeanna Schoonmaker.

Access and use the app here: https://share.streamlit.io/jschoonmaker/linkedin_network/main/li.py
